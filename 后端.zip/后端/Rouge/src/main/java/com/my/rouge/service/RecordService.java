package com.my.rouge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.Record;
import com.my.rouge.pojo.RecordVo;

import java.util.List;

public interface RecordService {

    void add(Record record);

    List<RecordVo> getById(Long userId);

    void updateOldTime(Record record);

    Page<Record> getPage(Integer pageNum, Integer pageSize, String queryInput,String queryState);

    void update(Record record);

    void delete(Integer id);

    Page<Record> getByPageAnMake(Integer pageNum, Integer pageSize, String queryInput);
}
