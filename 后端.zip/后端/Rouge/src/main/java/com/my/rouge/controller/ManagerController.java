package com.my.rouge.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.Manager;
import com.my.rouge.pojo.User;
import com.my.rouge.service.ManagerService;
import com.my.rouge.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/manager")
public class ManagerController {

    @Autowired
    private ManagerService managerService;


    @PostMapping("/login")
    public Result login(@RequestBody  Manager manager){
        Manager managerInfo = managerService.login(manager);
        if (managerInfo == null){
            return Result.error("账号或密码不正确！");
        }
        return Result.success(managerInfo);
    }


    /**
     *
     * @param pageNum:页数
     * @param pageSize：一页几条数据
     * @param queryInput：检索条件
     * @return json
     */
    @GetMapping("/getStaffList")
    public Result<Page<Manager>> getAll(Integer pageNum, Integer pageSize,
                                     @RequestParam(required = false) String queryInput){
        return  Result.success(managerService.getAll(pageNum,pageSize,queryInput));
    }

    //注册员工
    @PostMapping("/addStaff")
    public Result addStaff(@RequestBody  Manager manager){
        if (manager.getAccount().isEmpty() || manager.getPhone().isEmpty() || manager.getName().isEmpty() || manager.getPassword().isEmpty()) {
            return Result.error("参数不能为空");
        }
        //先判断账号或手机号是否重复
        boolean bol = managerService.accountOrPhoneIsNull(manager);
        if (bol){
            return Result.error("账号或手机号重复");
        }
        managerService.addStaff(manager);
        return Result.success();
    }

    @PutMapping("/updateStaff")
    public Result updateStaff(@RequestBody  Manager manager){
        if (manager.getAccount().isEmpty() || manager.getPhone().isEmpty() || manager.getName().isEmpty() || manager.getPassword().isEmpty()) {
            return Result.error("参数不能为空");
        }
        //先判断账号或手机号是否重复 - 不改手机号肯定重复
        boolean bol = managerService.updateStaffAccountOrPhone(manager);
        if (bol){
            return Result.error("修改的账号或手机号重复");
        }
        managerService.updateStaff(manager);
        return Result.success();
    }

    //删除员工信息
    @DeleteMapping("/deleteStaff")
    public Result deleteStaff(Integer id){
        System.out.println("访问");
        if (id == null){
            return Result.error("用户id为空");
        }
        managerService.deleteStaff(id);
        return Result.success();
    }

    //查询个人信息
    @GetMapping("/getUserInfo")
    public Result<Manager> getUserInfo(Integer id) {
        System.out.println("来" + id);
        return Result.success(managerService.getUserInfo(id));
    }
}
