package com.my.rouge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.mapper.PhotoMapper;
import com.my.rouge.pojo.Photo;
import com.my.rouge.service.PhotoService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PhotoServiceImpl implements PhotoService {

    @Resource
    private PhotoMapper photoMapper;

    @Override
    public List<Photo> getAll() {
        return photoMapper.selectList(null);
    }

    //查询所有摄影师带分页
    @Override
    public Page<Photo> getPhotoByPage(Integer pageNum, Integer pageSize, String queryInput) {
        Page<Photo> page = new Page<>(pageNum,pageSize);
        QueryWrapper<Photo> queryWrapper = new QueryWrapper<>();
        //如果没有传入摄影师名称正常全部查询
        if (queryInput == null){
           return photoMapper.selectPage(page,queryWrapper);
        }
        //传入摄影师名称 使用条件构造器 进行查询
        queryWrapper.like("name",queryInput);
        return photoMapper.selectPage(page,queryWrapper);
    }

    //注册
    @Override
    public void add(Photo photo) {
        photoMapper.insert(photo);
    }

    //修改
    @Override
    public void updatePhoto(Photo photo) {
        photoMapper.updateById(photo);
    }

    @Override
    public void deletePhoto(String id) {
        UpdateWrapper<Photo> updateWrapper = new UpdateWrapper<>();
        Photo photo = photoMapper.selectById(id);
        updateWrapper.eq("id", id);
        if (photo.getVersion().equals("在职")){
            updateWrapper.set("version", "离职");
        }else {
            updateWrapper.set("version", "在职");
        }
        photoMapper.update(null, updateWrapper);
    }
}
