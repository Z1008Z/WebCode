package com.my.rouge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.Photo;

import java.util.List;

public interface PhotoService {

    List<Photo> getAll();

    Page<Photo> getPhotoByPage(Integer pageNum, Integer pageSize, String queryInput);

    void add(Photo photo);

    void updatePhoto(Photo photo);

    void deletePhoto(String id);
}
