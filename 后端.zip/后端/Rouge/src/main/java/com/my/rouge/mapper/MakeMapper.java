package com.my.rouge.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.my.rouge.pojo.Make;

public interface MakeMapper extends BaseMapper<Make> {
}
