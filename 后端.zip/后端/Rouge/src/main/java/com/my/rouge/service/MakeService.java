package com.my.rouge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.Make;
import com.my.rouge.pojo.Photo;

import java.util.List;

public interface MakeService {
    List<Make> getAll();

    Page<Make> getMakeByPage(Integer pageNum, Integer pageSize, String queryInput);

    void add(Make make);

    void updateMake(Make make);

    void deletePhoto(String id);
}
