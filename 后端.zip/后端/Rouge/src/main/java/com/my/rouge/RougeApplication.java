package com.my.rouge;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.my.rouge.mapper")
public class RougeApplication {

    public static void main(String[] args) {
        SpringApplication.run(RougeApplication.class, args);
    }

}
