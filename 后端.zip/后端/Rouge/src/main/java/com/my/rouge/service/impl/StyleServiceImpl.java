package com.my.rouge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.mapper.StyleMapper;
import com.my.rouge.pojo.Style;
import com.my.rouge.service.StyleService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StyleServiceImpl implements StyleService {

    //注入通用Mapper
    @Resource
    private StyleMapper styleMapper;

    @Override
    public List<Style> getAll() {
        return styleMapper.selectList(null);
    }


    @Override
    public Page<Style> getStyleByPage(Integer pageNum, Integer pageSize, String queryInput) {
        Page<Style> page = new Page<>(pageNum,pageSize);
        QueryWrapper<Style> queryWrapper = new QueryWrapper<>();
        //如果没有传入摄影师名称正常全部查询
        if (queryInput == null){
            return styleMapper.selectPage(page,queryWrapper);
        }
        //传入摄影师名称 使用条件构造器 进行查询
        queryWrapper.like("type",queryInput);
        return styleMapper.selectPage(page,queryWrapper);
    }

    @Override
    public void add(Style style) {
        styleMapper.insert(style);
    }

    @Override
    public void updateStyle(Style style) {
        styleMapper.updateById(style);
    }

    @Override
    public void deleteMake(String id) {
        UpdateWrapper<Style> updateWrapper = new UpdateWrapper<>();
        Style style = styleMapper.selectById(id);
        updateWrapper.eq("id", id);
        if (style.getVersion().equals("上架")){
            updateWrapper.set("version", "下架");
        }else {
            updateWrapper.set("version", "上架");
        }
        styleMapper.update(null, updateWrapper);
    }
}
