package com.my.rouge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.User;
import com.my.rouge.utils.Result;

import java.util.List;

public interface UserService {
    //查看是否为新客户
    User queryUserByPhone(String phone);

    //老客户
    void addUser(User user);

    void updateUserName(User user);

    Page<User> getAll(Integer pageNum, Integer pageSize,String queryInput);

    List<User> getUser();
}
