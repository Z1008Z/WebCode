/*
 Navicat Premium Data Transfer

 Source Server         : MySQL5
 Source Server Type    : MySQL
 Source Server Version : 50016
 Source Host           : localhost:3308
 Source Schema         : rouge

 Target Server Type    : MySQL
 Target Server Version : 50016
 File Encoding         : 65001

 Date: 28/02/2025 11:07:25
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for make
-- ----------------------------
DROP TABLE IF EXISTS `make`;
CREATE TABLE `make`  (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL COMMENT '化妆师姓名',
  `phone` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL COMMENT '化妆师电话',
  `pic` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL COMMENT '化妆师职业照',
  `version` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT '在职',
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of make
-- ----------------------------
INSERT INTO `make` VALUES (1, '乐瑶', '15144132219', '\r\nhttps://lzh-vue.oss-cn-beijing.aliyuncs.com/user-06.jpg', '在职');
INSERT INTO `make` VALUES (2, '阿悦', '15144445555', '\r\nhttps://lzh-vue.oss-cn-beijing.aliyuncs.com/user-02.jpg', '在职');
INSERT INTO `make` VALUES (3, '政', '15133336666', 'https://lzh-vue.oss-cn-beijing.aliyuncs.com/user-04.jpg', '离职');

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `account` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `role` int(5) NULL DEFAULT 1,
  `sex` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES (1, '卢大王', 'admin', '123456', 0, '男', '15144132219');
INSERT INTO `manager` VALUES (2, '马小悦', 'maxiaoyue', '123456', 1, '女', '15144442222');
INSERT INTO `manager` VALUES (3, '小卢', 'xiaolu', '123456', 1, '男', '15144444444');
INSERT INTO `manager` VALUES (10, '卢政宏大王', 'ludawang', '123456', 1, '女', '15144443333');

-- ----------------------------
-- Table structure for photo
-- ----------------------------
DROP TABLE IF EXISTS `photo`;
CREATE TABLE `photo`  (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `pic` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `version` varchar(5) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '在职',
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of photo
-- ----------------------------
INSERT INTO `photo` VALUES (1, '昭阳', '18888888888', '\r\nhttps://lzh-vue.oss-cn-beijing.aliyuncs.com/user-01.jpg', '在职');
INSERT INTO `photo` VALUES (2, '米彩', '13333333333', 'https://lzh-vue.oss-cn-beijing.aliyuncs.com/user-05.jpg', '在职');
INSERT INTO `photo` VALUES (3, '简微', '16666666666', 'https://lzh-vue.oss-cn-beijing.aliyuncs.com/user-03.jpg', '在职');
INSERT INTO `photo` VALUES (4, '加菲大王', '12222222222', 'https://lzh-vue.oss-cn-beijing.aliyuncs.com/20250210115630jiaFei.png', '离职');

-- ----------------------------
-- Table structure for record
-- ----------------------------
DROP TABLE IF EXISTS `record`;
CREATE TABLE `record`  (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(255) NULL DEFAULT NULL,
  `make_id` bigint(255) NULL DEFAULT NULL,
  `photo_id` bigint(11) NULL DEFAULT NULL,
  `style_id` bigint(11) NULL DEFAULT NULL,
  `time` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '未出片',
  `old_time` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL COMMENT '到店时间',
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of record
-- ----------------------------
INSERT INTO `record` VALUES (6, 1, 1, 3, 1, '2024-12-07', '已预约', '2025-01-22-16:00');
INSERT INTO `record` VALUES (7, 1, 3, 3, 5, '2024-12-07', '已预约', '2024-12-18-16:00');
INSERT INTO `record` VALUES (9, 1, 2, 3, 4, '2024-12-07', '已预约', '2024-12-20-15:00');
INSERT INTO `record` VALUES (12, 3, 3, 2, 5, '2024-12-08', '已预约', '2024-12-18-14:00');
INSERT INTO `record` VALUES (16, 3, 3, 1, 1, '2024-12-08', '已预约', '2024-12-19-14:00');
INSERT INTO `record` VALUES (17, 3, 2, 2, 1, '2024-12-08', '已预约', '2024-12-18-14:00');
INSERT INTO `record` VALUES (18, 2, 2, 2, 3, '2024-12-08', '已出片', NULL);
INSERT INTO `record` VALUES (19, 1, 1, 2, 4, '2024-12-17', '已出片', NULL);
INSERT INTO `record` VALUES (20, 1, 2, 1, 5, '2024-12-17', '未出片', NULL);
INSERT INTO `record` VALUES (21, 1, 3, 1, 3, '2024-12-17', '已出片', NULL);
INSERT INTO `record` VALUES (22, 4, 2, 3, 4, '2024-12-17', '未出片', NULL);
INSERT INTO `record` VALUES (24, 1, 3, 4, 5, '2025-02-10', '已预约', '2025-02-20-16:00');

-- ----------------------------
-- Table structure for style
-- ----------------------------
DROP TABLE IF EXISTS `style`;
CREATE TABLE `style`  (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `type` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL COMMENT '妆造类型',
  `info` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL COMMENT '描述',
  `version` varchar(11) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NOT NULL DEFAULT '上架' COMMENT '默认0为上架，1为下架',
  `pic` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL COMMENT '图片链接',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '价格',
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of style
-- ----------------------------
INSERT INTO `style` VALUES (1, '战国袍（有拍摄）', '1小时拍摄\\拍摄40张全送\\8张精修', '上架', 'https://lzh-vue.oss-cn-beijing.aliyuncs.com/rouge-01.jpg', 788.00);
INSERT INTO `style` VALUES (2, '闺蜜汉服、朝服款（有拍摄）', '1小时拍摄\\拍摄50张全送\\15张精修', '上架', '\r\nhttps://lzh-vue.oss-cn-beijing.aliyuncs.com/rouge-02.jpg', 588.00);
INSERT INTO `style` VALUES (3, '闺蜜格格款（有拍摄）', '1小时拍摄\\拍摄50张全送\\15张精修', '上架', '\r\nhttps://lzh-vue.oss-cn-beijing.aliyuncs.com/rouge-03.jpg', 888.00);
INSERT INTO `style` VALUES (4, '闺蜜簪花、旗袍套餐（有拍摄）', '1小时拍摄\\拍摄50张全送\\15张精修', '上架', '\r\nhttps://lzh-vue.oss-cn-beijing.aliyuncs.com/rouge-04.jpg', 998.00);
INSERT INTO `style` VALUES (5, '凤凰古镇（有拍摄）', '1小时拍摄\\拍摄50张全送\\15张精修', '上架', '\r\nhttps://lzh-vue.oss-cn-beijing.aliyuncs.com/rouge-05.jpg', 558.00);
INSERT INTO `style` VALUES (8, '好好好', '修改测试', '下架', 'https://lzh-vue.oss-cn-beijing.aliyuncs.com/20250219111755zixun02.png', 1299.00);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  `time` varchar(20) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = gb2312 COLLATE = gb2312_chinese_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '小卢', '15144132219', '2024-12-02');
INSERT INTO `user` VALUES (2, '马小悦', '15144132222', '2024-12-02');
INSERT INTO `user` VALUES (3, '用户4497', '15144111111', '2024-12-02');
INSERT INTO `user` VALUES (4, '小测试', '15144442222', '2024-12-25');
INSERT INTO `user` VALUES (8, '测试', '13596555555', '2024-12-27');

SET FOREIGN_KEY_CHECKS = 1;
