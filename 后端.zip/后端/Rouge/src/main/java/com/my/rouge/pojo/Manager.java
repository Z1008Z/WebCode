package com.my.rouge.pojo;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Manager {
    private Long id;
    private String name;
    private String account;
    private String password;
    private Integer role;
    private String sex;
    private String phone;
}
