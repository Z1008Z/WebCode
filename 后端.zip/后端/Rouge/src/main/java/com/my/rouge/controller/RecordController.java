package com.my.rouge.controller;

import com.my.rouge.pojo.Record;
import com.my.rouge.service.RecordService;
import com.my.rouge.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/record")
public class RecordController {

    @Autowired
    private RecordService recordService;

    //添加预约记录
    @PostMapping("/add")
    public Result add(@RequestBody Record record) {
        System.out.println("进入");
        //注册信息，不想搞校验了
        recordService.add(record);
        return Result.success();
    }

    //查询当前登录用户预约信息
    @GetMapping("/getById")
    public Result getById(Long userId) {
        System.out.println(userId);
        return Result.success(recordService.getById(userId));
    }

    //预约取片,修改时间
    @PutMapping("/updateOldTime")
    public Result updateOldTime(@RequestBody Record record){
        if (record.getOldTime() != null){
            recordService.updateOldTime(record);
            return Result.success();
        }
        return Result.error("当前预约时间为空");
    }

    //查询不等于已预约的记录带分页
    @GetMapping("/getByPage")
    public Result getByPage(Integer pageNum, Integer pageSize,
                            @RequestParam(required = false) String queryInput,
                            @RequestParam(required = false) String queryState){

        return  Result.success(recordService.getPage(pageNum,pageSize,queryInput,queryState));

    }

    //查询所有已预约的记录带分页
    @GetMapping("/getByPageAnMake")
    public Result getByPageAnMake(Integer pageNum, Integer pageSize,
                            @RequestParam(required = false) String queryInput){

        return  Result.success(recordService.getByPageAnMake(pageNum,pageSize,queryInput));

    }

    //修改记录
    @PutMapping("/update")
    public Result update(@RequestBody  Record record){
        recordService.update(record);
        return Result.success();
    }

    //删除记录
    @DeleteMapping("/delete")
    public Result delete(Integer id){
        recordService.delete(id);
        return Result.success();
    }
}
