package com.my.rouge.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecordVo {
    private Long id;
    private String userName;
    private String makeName;
    private String photoName;
    private String styleName;
    private String time;
    private String state;
    private String oldTime;
}
