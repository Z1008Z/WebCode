package com.my.rouge.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.my.rouge.pojo.Style;
import org.springframework.stereotype.Repository;

@Repository
public interface StyleMapper extends BaseMapper<Style> {
}
