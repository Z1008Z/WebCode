package com.my.rouge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.Manager;

public interface ManagerService {

    //查询账号查询用户信息
    Manager queryManagerByAccount(Manager manager);

    //登录
    Manager login(Manager manager);

    //查询
    Page<Manager> getAll(Integer pageNum, Integer pageSize, String queryInput);

    boolean accountOrPhoneIsNull(Manager manager);

    void addStaff(Manager manager);

    void updateStaff(Manager manager);

    boolean updateStaffAccountOrPhone(Manager manager);

    //删除
    void deleteStaff(Integer id);

    Manager getUserInfo(Integer id);
}
