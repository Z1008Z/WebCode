package com.my.rouge.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

//Style为当前妆造样式类
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Style {
    private Long id;
    private String type;
    private String info;
    private String pic;
    private String version;
    private String price;
}
