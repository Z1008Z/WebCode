package com.my.rouge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RougeApplicationTests {

    @Test
    void contextLoads() {
    }

}
