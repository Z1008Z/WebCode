package com.my.rouge.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.User;
import com.my.rouge.service.UserService;
import com.my.rouge.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    //一键预约注册用户
    @PostMapping("/addUser")
    public Result addUser(@RequestBody User user){
        if (user.getPhone() == "" || user.getName() == ""){
            return Result.error("参数为空");
        }
        //先看一下这个手机号是否注册过
        User userByMySql = userService.queryUserByPhone(user.getPhone());
        //已存在返回true
        if (userByMySql != null){
            System.out.println(userByMySql);
            return  Result.success(userByMySql);
        }
        //新顾客需要注册操作
        userService.addUser(user);
        //添加完成后 根据手机号查询id  返回id
        User user1 = userService.queryUserByPhone(user.getPhone());
        return Result.success(user1);
    }

    //修改昵称
    @PutMapping("/updateUserName")
    public Result updateUserName(@RequestBody User user){
        if (user.getName() == null){
            return Result.error("用户名称不能为空");
        }
        userService.updateUserName(user);
        return Result.success();
    }

    //分页查询用户信息
    @GetMapping("/getAll")
    public Result<Page<User>> getAll(Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String queryInput
    ){
        System.out.println("接值" + queryInput);
        return  Result.success(userService.getAll(pageNum,pageSize,queryInput));
    }

    //查询所有用户信息
    @GetMapping("/getUser")
    public Result<List<User>> getUser(){
        return Result.success(userService.getUser());
    }

}
