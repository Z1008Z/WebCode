package com.my.rouge.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.my.rouge.pojo.Record;
import com.my.rouge.pojo.RecordVo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecordMapper extends BaseMapper<Record> {

    //查询当前id预约记录
    @Select(" SELECT r.id, u.name AS userName, m.name AS makeName, p.name AS photoName, s.type AS styleName, r.time, r.state,r.old_time" +
            "        FROM record r" +
            "        LEFT  JOIN user u ON r.user_id = u.id" +
            "        LEFT JOIN make m ON r.make_id = m.id" +
            "        LEFT JOIN photo p ON r.photo_id = p.id" +
            "        LEFT JOIN style s ON r.style_id = s.id" +
            "        WHERE r.user_id = #{userId}")
    List<RecordVo> getById(Long userId);



    @Select("select u.id from record r ")
    String queryIdByName();

}
