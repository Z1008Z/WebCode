package com.my.rouge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.mapper.MakeMapper;
import com.my.rouge.pojo.Make;
import com.my.rouge.pojo.Photo;
import com.my.rouge.service.MakeService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MakeServiceImpl implements MakeService {

    @Resource
    private MakeMapper makeMapper;

    @Override
    public List<Make> getAll() {
        return makeMapper.selectList(null);
    }

    //所有妆造师带分页
    @Override
    public Page<Make> getMakeByPage(Integer pageNum, Integer pageSize, String queryInput) {
        Page<Make> page = new Page<>(pageNum,pageSize);
        QueryWrapper<Make> queryWrapper = new QueryWrapper<>();
        //如果没有传入摄影师名称正常全部查询
        if (queryInput == null){
            return makeMapper.selectPage(page,queryWrapper);
        }
        //传入摄影师名称 使用条件构造器 进行查询
        queryWrapper.like("name",queryInput);
        return makeMapper.selectPage(page,queryWrapper);
    }

    @Override
    public void add(Make make) {
        makeMapper.insert(make);
    }

    @Override
    public void updateMake(Make make) {
        makeMapper.updateById(make);
    }

    @Override
    public void deletePhoto(String id) {
        UpdateWrapper<Make> updateWrapper = new UpdateWrapper<>();
        Make make = makeMapper.selectById(id);
        updateWrapper.eq("id", id);
        if (make.getVersion().equals("在职")){
            updateWrapper.set("version", "离职");
        }else {
            updateWrapper.set("version", "在职");
        }
        makeMapper.update(null, updateWrapper);
    }
}
