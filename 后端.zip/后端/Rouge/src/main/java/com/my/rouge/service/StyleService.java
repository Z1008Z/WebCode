package com.my.rouge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.pojo.Style;

import java.util.List;

public interface StyleService {
    List<Style> getAll();

    Page<Style> getStyleByPage(Integer pageNum, Integer pageSize, String queryInput);

    void add(Style style);

    void updateStyle(Style style);

    void deleteMake(String id);
}
