package com.my.rouge.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.my.rouge.pojo.Photo;

public interface PhotoMapper extends BaseMapper<Photo> {
}
