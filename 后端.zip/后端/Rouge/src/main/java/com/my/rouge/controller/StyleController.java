package com.my.rouge.controller;

import com.my.rouge.pojo.Make;
import com.my.rouge.pojo.Style;
import com.my.rouge.service.StyleService;
import com.my.rouge.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//妆造样式控制层
@RestController
@RequestMapping("/style")
@CrossOrigin
public class StyleController {

    @Autowired
    private StyleService styleService;

    //查询所有妆造风格
    @GetMapping("/getAll")
    public Result<List<Style>> getAll(){
        //调用业务层
        List<Style> list = styleService.getAll();
        return Result.success(list);
    }

    //获取妆造风格带分页
    @GetMapping("/getStyleByPage")
    public Result getStyleByPage(Integer pageNum, Integer pageSize,
                                @RequestParam(required = false) String queryInput){

        return  Result.success(styleService.getStyleByPage(pageNum,pageSize,queryInput));

    }

    //添加妆造风格
    @PostMapping("/add")
    public Result add(@RequestBody Style style) {
        styleService.add(style);
        return Result.success();
    }

    //修改妆造风格
    @PutMapping("/updateStyle")
    public Result updateStyle(@RequestBody Style style){
        styleService.updateStyle(style);
        return Result.success();
    }

    //删除妆造风格 - 下架操作
    @PatchMapping("/deleteStyle")
    public Result deleteMake(String id) throws Exception {
        styleService.deleteMake(id);
        return Result.success();
    }
}
