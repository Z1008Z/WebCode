package com.my.rouge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.mapper.ManagerMapper;
import com.my.rouge.pojo.Manager;
import com.my.rouge.service.ManagerService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

@Service
public class ManagerServiceImpl implements ManagerService {

    @Resource
    private ManagerMapper managerMapper;


    //根据账号查询用户信息
    @Override
    public Manager queryManagerByAccount(Manager manager) {
        QueryWrapper<Manager> queryWrapper = new QueryWrapper();
        queryWrapper.eq("account",manager.getAccount());;
        return managerMapper.selectOne(queryWrapper);
    }

    //校验Miami
    @Override
    public Manager login(Manager manager) {
       Manager manager1 = queryManagerByAccount(manager);
       //密码不正确
       if (manager1 == null || !manager1.getPassword().equals(manager.getPassword())){
            return null;
       }
       return manager1;
    }

    //查询
    @Override
    public Page<Manager> getAll(Integer pageNum, Integer pageSize, String queryInput) {
        Page<Manager> page = new Page<>(pageNum,pageSize);
        QueryWrapper<Manager> queryWrapper = new QueryWrapper();
        if (queryInput == null){
            queryWrapper.eq("role",1);
            return managerMapper.selectPage(page,queryWrapper);
        }

        queryWrapper.and(wrapper -> wrapper.like("name", queryInput)
                        .or()
                        .like("account", queryInput)
                        .or()
                        .like("phone", queryInput))
                .eq("role", 1);
        return managerMapper.selectPage(page,queryWrapper);
    }

    /**
     * 注册前验证是否重复
     * @return
     */
    @Override
    public boolean accountOrPhoneIsNull(Manager manager) {
        QueryWrapper<Manager> queryWrapper = new QueryWrapper();
        queryWrapper.eq("account",manager.getAccount())
                .or().eq("phone",manager.getPhone());
        Long count = managerMapper.selectCount(queryWrapper);
        //如果有数据那就说明被占用
        if ( count > 0){
            return true;
        }
        return false;
    }

    @Override
    public void addStaff(Manager manager) {
        managerMapper.insert(manager);
    }

    @Override
    public void updateStaff(Manager manager) {
        managerMapper.updateById(manager);
    }

    //修改排除自己 账号 手机号
    @Override
    public boolean updateStaffAccountOrPhone(Manager manager) {
        QueryWrapper<Manager> queryWrapper = new QueryWrapper();
        queryWrapper.eq("account", manager.getAccount()).or()
                .eq("phone", manager.getPhone());
        Long count = managerMapper.selectCount(queryWrapper);
        //如果大于一条那就说明有其他的 占用
        if (count > 1){
            return true;
        }
        return false;
    }

    @Override
    public void deleteStaff(Integer id) {
        managerMapper.deleteById(id);
    }

    @Override
    public Manager getUserInfo(Integer id) {
        return managerMapper.selectById(id);
    }
}
