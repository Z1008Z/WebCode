package com.my.rouge.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class Record {
    @TableId("id")
    private Long id;
    @TableField("user_id")
    private Long userId;
    @TableField("make_id")
    private Long makeId;
    @TableField("photo_id")
    private Long photoId;
    @TableField("style_id")
    private Long styleId;
    private String time;
    private String state;
    @TableField("old_time")
    private String oldTime;

}
