package com.my.rouge.controller;

import com.my.rouge.pojo.Make;
import com.my.rouge.pojo.Photo;
import com.my.rouge.service.MakeService;
import com.my.rouge.service.PhotoService;
import com.my.rouge.utils.AliOssUtils;
import com.my.rouge.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/photo")
public class PhotoController {

    @Autowired
    private PhotoService photoService;

    @GetMapping("/getAll")
    public Result<List<Photo>> getAll(){
        List<Photo> list  = photoService.getAll();
        return Result.success(list);
    }

    //-----------------------------------------------------

    //获取摄影师带分页
    @GetMapping("/getPhotoByPage")
    public Result getPhotoByPage(Integer pageNum, Integer pageSize,
                                  @RequestParam(required = false) String queryInput){

        return  Result.success(photoService.getPhotoByPage(pageNum,pageSize,queryInput));

    }

    //上传文件 阿里云  公共方法
    @PostMapping("/uploadAliOss")
    public Result uploadAliOss(MultipartFile file) throws Exception {
        //获取文件名称
        String fileName = file.getOriginalFilename();
        System.out.println(fileName);
        // 加一个时间戳
        fileName = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + fileName;
        //调用MultipartFile提供的输入流对象
        String url = AliOssUtils.fileUpload(fileName,file.getInputStream());
        return Result.success(url);
    }

    //删除阿里云图片接口
    @PatchMapping("/deleteAliyunFile")
    public Result deleteAliyunFile(String oldUrl) throws Exception {
        AliOssUtils.remove(oldUrl);
        return Result.success("删除成功");
    }


    //注册摄影师
    @PostMapping("/add")
    public Result add(@RequestBody Photo photo) {
        photoService.add(photo);
        return Result.success();
    }

    //修改摄影师
    @PutMapping("/updatePhoto")
    public Result updatePhoto(@RequestBody Photo photo){
        photoService.updatePhoto(photo);
        return Result.success();
    }

    //删除摄影师
    @PatchMapping("/deletePhoto")
    public Result deletePhoto(String id) throws Exception {

        photoService.deletePhoto(id);
        return Result.success();
    }
}
