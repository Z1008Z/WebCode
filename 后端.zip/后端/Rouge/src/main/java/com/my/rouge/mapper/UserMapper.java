package com.my.rouge.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.my.rouge.pojo.Style;
import com.my.rouge.pojo.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserMapper extends BaseMapper<User> {
}
