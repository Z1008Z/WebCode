package com.my.rouge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.my.rouge.mapper.RecordMapper;
import com.my.rouge.pojo.Record;
import com.my.rouge.pojo.RecordVo;
import com.my.rouge.service.RecordService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class RecordServiceImpl implements RecordService {

    @Resource
    private RecordMapper recordMapper;

    //添加预约记录
    @Override
    public void add(Record record) {
        String time = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        record.setTime(time);
        recordMapper.insert(record);
    }

    //查询当前id预约记录
    @Override
    public List<RecordVo> getById(Long userId) {
        return recordMapper.getById(userId);
    }

    //点击预约，修改预约时间
    @Override
    public void updateOldTime(Record record) {
        record.setState("已预约");
        recordMapper.updateById(record);
    }

    //查询所有记录不等于已预约 分页
    @Override
    public Page<Record> getPage(Integer pageNum, Integer pageSize, String queryInput,String queryState) {
        Page<Record> page = new Page<>(pageNum,pageSize);
        QueryWrapper<Record> queryWrapper = new QueryWrapper();
        queryWrapper.ne("state","已预约");
        if (queryInput == null && queryState == null){
            return recordMapper.selectPage(page,queryWrapper);
        }
        if (queryInput != null){
            queryWrapper.and(wrapper -> wrapper.like("time",queryInput));
        }

        if (queryState != null){
            queryWrapper.and(wrapper -> wrapper.eq("state",queryState));
        }

        return recordMapper.selectPage(page,queryWrapper);
    }

    //修改记录信息
    @Override
    public void update(Record record) {
        recordMapper.updateById(record);
    }

    //删除记录
    @Override
    public void delete(Integer id) {
        recordMapper.deleteById(id);
    }

    //查询所有已预约记录
    @Override
    public Page<Record> getByPageAnMake(Integer pageNum, Integer pageSize, String queryInput) {
        Page<Record> page = new Page<>(pageNum,pageSize);
        QueryWrapper<Record> queryWrapper = new QueryWrapper();
        queryWrapper.eq("state","已预约");
        if (queryInput == null){
            return recordMapper.selectPage(page,queryWrapper);
        }
        if (queryInput != null){
            queryWrapper.and(wrapper -> wrapper.like("old_time",queryInput));
        }

        return recordMapper.selectPage(page,queryWrapper);
    }
}
