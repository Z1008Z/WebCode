package com.my.rouge.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Make {
    private Long id;
    private String name;
    private String phone;
    private String pic;
    private String version;
}
