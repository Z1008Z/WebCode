package com.my.rouge.controller;

import com.my.rouge.pojo.Make;
import com.my.rouge.pojo.Photo;
import com.my.rouge.service.MakeService;
import com.my.rouge.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/make")
public class MakeController {

    @Autowired
    private MakeService makeService;

    @GetMapping("/getAll")
    public Result<List<Make>> getAll(){
        List<Make> makeList = makeService.getAll();
        return Result.success(makeList);
    }

    //获取妆造师带分页
    @GetMapping("/getMakeByPage")
    public Result getMakeByPage(Integer pageNum, Integer pageSize,
                                 @RequestParam(required = false) String queryInput){

        return  Result.success(makeService.getMakeByPage(pageNum,pageSize,queryInput));

    }

    //注册妆造师
    @PostMapping("/add")
    public Result add(@RequestBody Make make) {
        makeService.add(make);
        return Result.success();
    }

    //修改妆造师
    @PutMapping("/updateMake")
    public Result updateMake(@RequestBody Make make){
        makeService.updateMake(make);
        return Result.success();
    }

    //删除妆造师 - 下架操作
    @PatchMapping("/deleteMake")
    public Result deleteMake(String id) throws Exception {
        makeService.deletePhoto(id);
        return Result.success();
    }
}
