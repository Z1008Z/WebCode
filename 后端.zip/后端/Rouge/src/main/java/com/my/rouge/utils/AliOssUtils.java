package com.my.rouge.utils;

import com.aliyun.oss.*;
import com.aliyun.oss.common.auth.CredentialsProvider;
import com.aliyun.oss.common.auth.DefaultCredentialProvider;
import com.aliyun.oss.common.comm.SignVersion;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;

import java.io.InputStream;


public class AliOssUtils {

    //公共的成员变量

    //节点
    private static final String ENDPOINT  = "https://oss-cn-beijing.aliyuncs.com";
    //秘钥
    private static final String ACCESS_KEY_ID = "LTAI5tQLDVF4kyisQrNDm68g";
    private static final String ACCESS_KEY_SECRET = "r71k2sKodSpZktsVxryX1KP4CzKS2g";
    // 填写Bucket名称，例如examplebucket。
    private static final String BUCKET_NAME = "lzh-vue";

    //工具类
    public static String fileUpload(String objectName, InputStream stream) throws Exception {
        //创建凭证提取器，加载凭证
        CredentialsProvider credentialsProvider = new DefaultCredentialProvider(ACCESS_KEY_ID, ACCESS_KEY_SECRET);

        String region = "cn-beijing";

        // 创建OSSClient实例。
        ClientBuilderConfiguration clientBuilderConfiguration = new ClientBuilderConfiguration();
        clientBuilderConfiguration.setSignatureVersion(SignVersion.V4);
        OSS ossClient = OSSClientBuilder.create()
                .endpoint(ENDPOINT)
                .credentialsProvider(credentialsProvider)
                .clientConfiguration(clientBuilderConfiguration)
                .region(region)
                .build();

        //声明返回值
        String url = "";

        try {
            PutObjectRequest putObjectRequest = new PutObjectRequest(BUCKET_NAME, objectName, stream);
            //oss客户端
            PutObjectResult result = ossClient.putObject(putObjectRequest);

            //返回值的问题 需要返回上传成功后的文件的访问地址
            //看一看访问地址的组成
            //https://lzh-vue.oss-cn-beijing.aliyuncs.com/rouge-01.jpg
            //https://bucket名称.区域节点/objectName

            url = "https://" + BUCKET_NAME + "." + ENDPOINT.substring(ENDPOINT.lastIndexOf("/") + 1) + "/"  + objectName;

        } catch (OSSException oe) {
            System.out.println("Caught an OSSException, which means your request made it to OSS, "
                    + "but was rejected with an error response for some reason.");
            System.out.println("Error Message:" + oe.getErrorMessage());
            System.out.println("Error Code:" + oe.getErrorCode());
            System.out.println("Request ID:" + oe.getRequestId());
            System.out.println("Host ID:" + oe.getHostId());
        } catch (ClientException ce) {
            System.out.println("Caught an ClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with OSS, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message:" + ce.getMessage());
        } finally {
            if (ossClient != null) {
                ossClient.shutdown();
            }
        }
        return url;
    }


    //删除阿里云文件方法
    public static void remove(String url) throws Exception{
        //截取文件名， 从 / 往后截取
        url = url.substring(url.lastIndexOf("/") + 1);
        //创建Oss客户端实例,地域节点，秘钥，值
        OSS ossClient = new OSSClientBuilder().build(ENDPOINT, ACCESS_KEY_ID, ACCESS_KEY_SECRET);
        //删除文件
        ossClient.deleteObject(BUCKET_NAME,url);
        //关闭客户端
        ossClient.shutdown();
    }
}
